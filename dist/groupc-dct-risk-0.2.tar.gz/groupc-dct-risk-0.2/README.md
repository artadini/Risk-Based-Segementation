# pythonpackagesample
This is a simple minimal set of codes to create a Python Package

TEST PUSHING...
...
"# pythonpackagesample" 
# groupc_dct_risk
